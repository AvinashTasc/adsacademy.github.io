
-- --------------------------------------------------------

--
-- Table structure for table `items`
--

CREATE TABLE `items` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`id`, `name`, `price`) VALUES
(1, 'PANEER BUTTER MASALA', 360),
(2, 'PALAK PANEER', 400),
(3, 'MATAR PANEER', 380),
(4, 'PANEER TIKKA', 420),
(5, 'TANDOORI ROTI', 10),
(6, 'MISSI ROTI', 22),
(7, 'RUMALI ROTI', 20),
(8, 'BUTTER NAAN', 18),
(9, 'CHICKEN CHANGEJI', 450),
(10, 'BUTTER CHICKEN', 480),
(11, 'RARA CHICKEN', 460),
(12, 'CHILLI CHICKEN', 460);
