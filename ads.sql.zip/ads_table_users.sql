
-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `contact` varchar(255) NOT NULL,
  `city` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `contact`, `city`, `address`) VALUES
(10, 'AVINASH', 'apanchbhyia@gmail.com', '14e1b600b1fd579f47433b88e8d85291', '9988774455', 'dehradun', 'banjarawala road'),
(11, 'admin', 'admin@gmail.com', '0c909a141f1f2c0a1cb602b0b2d7d050', '9988776655', 'dehradun', 'banjarwala'),
(12, 'avinash', 'admin12@gmail.com', '14e1b600b1fd579f47433b88e8d85291', '9988776655', 'deh', 'jhjdsghgds'),
(13, 'avinash', 'avinash@gmail.com', '14e1b600b1fd579f47433b88e8d85291', '9988776655', 'deh', 'deh2');
