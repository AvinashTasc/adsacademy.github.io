
-- --------------------------------------------------------

--
-- Table structure for table `users_items`
--

CREATE TABLE `users_items` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `status` enum('Added to cart','Confirmed') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users_items`
--

INSERT INTO `users_items` (`id`, `user_id`, `item_id`, `status`) VALUES
(42, 7, 1, 'Confirmed'),
(43, 7, 2, 'Confirmed'),
(44, 8, 1, 'Confirmed'),
(45, 8, 2, 'Confirmed'),
(46, 8, 3, 'Confirmed'),
(47, 9, 2, 'Confirmed'),
(48, 9, 11, 'Confirmed'),
(49, 9, 6, 'Confirmed'),
(50, 9, 5, 'Confirmed'),
(51, 12, 1, 'Confirmed'),
(52, 12, 7, 'Confirmed'),
(53, 12, 11, 'Confirmed'),
(54, 13, 1, 'Confirmed'),
(55, 13, 2, 'Confirmed');
